package com.paypal.foodDelivery.Services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.paypal.foodDelivery.Repository.CustomerRepository;
import com.paypal.foodDelivery.model.Customer;
import com.paypal.foodDelivery.model.MenuItem;
import com.paypal.foodDelivery.model.Order;

@Service
public class CustomerServiceImpl implements CustomerService {
	
	@Autowired
    private CustomerRepository customerRepository ;
 
	@Override
	public void upload(List<Customer> customer) {
		customerRepository.save(customer);
		
	}

	@Override
	public String getCustomer() {
		List<Customer> Orders = customerRepository.findAll();
        String info = "";
        for(Customer c: Orders)
        {
        	info+=findinfoById(c.getId());
        }
        return info;
	}

	@Override
	public String findinfoById(Long id) {
		List<Order> price_list = customerRepository.findOne(id).getOrder_list();
		 String output = "";
		 for(Order o : price_list)
		 {
			 double price = 0d;
			 List<MenuItem> price_list1 = o.getItems();
			 for(MenuItem items : price_list1)
			 {
				 price+=items.getPrice();
			 }
			 
			 output += "Restaurant Name : " +o.getRestaurant().getName().toString() +
	    		   		"Customer Name :" + o.getCustomer().getName().toString() +
	    		   		"Order List :" + o.getItems().toString() +
	    		   		"Price : " + price + "\n";
		}
	    return output;
	}

}
