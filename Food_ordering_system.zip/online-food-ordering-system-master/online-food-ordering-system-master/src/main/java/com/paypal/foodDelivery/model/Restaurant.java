package com.paypal.foodDelivery.model;

import com.fasterxml.jackson.annotation.*;
import lombok.Data;
import lombok.NoArgsConstructor;
import javax.persistence.*;
import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Entity
@Data
@NoArgsConstructor
public class Restaurant {

    @GeneratedValue
    @Id
    private Long id;

    private String name;

    private String location;

    @JsonManagedReference
    @OneToMany(mappedBy = "restaurant", cascade = CascadeType.ALL, orphanRemoval = true)
   
    private List<Menu> menus;
    
    @OneToMany(mappedBy = "restaurant", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Order> order_list;
        
    public List<Order> getOrder_list() {
		return order_list;
	}
	public void setOrder_list(List<Order> order_list) 
	{
		this.order_list = order_list;
	}
	public Restaurant() {}
    public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public List<Menu> getMenus() {
		return menus;
	}
	public void setId(Long id) {
		this.id = id;
	}
	@JsonCreator
    public Restaurant(@JsonProperty("id") Long id, @JsonProperty("name") String name, @JsonProperty("location") String location, @JsonProperty("menus") List<Menu> menus) {
        this.name = name;
        this.location = location;
        if (menus != null ) {
            this.menus = menus;
            for (Menu menu : menus)
                {menu.setRestaurant(this);/*mr.save(menu);*/}
        }
    }
    
    

	

    public void setMenus(List<Menu> menus) {
		this.menus = menus;
	}
	@Override
    public String toString() {
        return "Restaurant{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", location='" + location + '\'' +
                ", menus=" + menus +
                '}';
    }

	public Long getId() {
		return id;
	}
    
}
