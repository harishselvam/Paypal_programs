package com.paypal.foodDelivery.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.paypal.foodDelivery.model.Menu;

import java.util.List;

public interface MenuRepository extends JpaRepository<Menu, Long> {
	
	  List<Menu> findByRestaurant_Id(Long id);
	  
	  void deleteByRestaurant_Id(Long id);
	 
}
