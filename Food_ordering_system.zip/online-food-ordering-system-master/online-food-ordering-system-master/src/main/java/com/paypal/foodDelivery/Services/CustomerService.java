package com.paypal.foodDelivery.Services;

import java.util.List;


import com.paypal.foodDelivery.model.Customer;

public interface CustomerService {
	
	public void upload(List<Customer> customer);
	public String getCustomer();
	public String findinfoById(Long id);
}
