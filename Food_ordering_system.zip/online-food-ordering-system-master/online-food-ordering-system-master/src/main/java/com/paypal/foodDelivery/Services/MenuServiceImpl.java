package com.paypal.foodDelivery.Services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.paypal.foodDelivery.Repository.MenuItemRepository;
import com.paypal.foodDelivery.Repository.MenuRepository;
import com.paypal.foodDelivery.model.Menu;
import com.paypal.foodDelivery.model.MenuItem;

@Service
public class MenuServiceImpl implements MenuServices{

	 @Autowired
	 private MenuRepository menuRepository;

	 @Autowired
	 private MenuItemRepository menuItemRepository;
	    
	@Transactional
	public void addItems(Long id, List<MenuItem> items) {
		Menu menu = menuRepository.findOne(id);
        if (menu == null)
            return ;

        for (MenuItem item : items)
            item.setMenu(menu);

        menuItemRepository.save(items);
		
	}

	@Transactional
	public List<Menu> getMenus() {
		return menuRepository.findAll();
	}

	@Transactional
	public Menu findMenuById(Long id) {
		return menuRepository.findOne(id);
	}

	@Transactional
	public void deleteAll() {
		menuRepository.deleteAll();;		
	}

	@Transactional
	public void deleteById(Long id) {
		menuRepository.delete(id);
	}

	@Transactional
	public List<MenuItem> getItems(Long id) {
		Menu menu = menuRepository.findOne(id);
        if (menu == null)
            return null;
        return menu.getItems();
	}

	@Override
	public void upload(List<Menu> menuList) {
		menuRepository.save(menuList);
		
	}

}
