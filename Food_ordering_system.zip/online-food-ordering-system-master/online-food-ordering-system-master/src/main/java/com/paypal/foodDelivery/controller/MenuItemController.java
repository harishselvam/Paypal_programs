package com.paypal.foodDelivery.controller;

import com.paypal.foodDelivery.Services.MenuItemsService;
import com.paypal.foodDelivery.model.MenuItem;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/menuItems")
public class MenuItemController {

    @Autowired
    private MenuItemsService menuItemsService;

    @GetMapping("/")
    public List<MenuItem> getMenItems() {
        return menuItemsService.getMenItems();
    }

    @GetMapping("/{id}")
    public MenuItem findMenuById(@PathVariable("id") Long id) {
        return menuItemsService.findMenuById(id);
    }

    @PostMapping("/")
    @ResponseStatus(HttpStatus.CREATED)
    public void upload(@RequestBody List<MenuItem> menuItemList) {
    	menuItemsService.upload(menuItemList);
    }

    @DeleteMapping("/")
    public void deleteAll() {
    	menuItemsService.deleteAll();
    }

    @DeleteMapping("/{id}")
    public void deleteById(@PathVariable("id") Long id) {
    	menuItemsService.deleteById(id);
    }

}
