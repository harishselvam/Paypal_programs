package com.paypal.foodDelivery.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import com.paypal.foodDelivery.Services.OrderService;
import com.paypal.foodDelivery.model.Order;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping("/orders")
public class OrderController 
{
	 @Autowired
	 private OrderService orderService;
	 
	@PostMapping("/")
    @ResponseStatus(HttpStatus.CREATED)
    public void upload(@RequestBody List<Order> orders) {
		orderService.upload(orders);
    }
	
	 @RequestMapping("/")
	    public List<Order> getOrder() {
	        
	        return orderService.getOrder();
	    }
	 
	 @RequestMapping("/{id}")
	    public Order findOrderById(@PathVariable("id") Long id) {
	        return orderService.findOrderById(id);
	    }
	 @RequestMapping("/{id}/info")
	    public String findOrderinfoById(@PathVariable("id") Long id) {
		 	return orderService.findOrderinfoById(id);
	    }
	 

}
