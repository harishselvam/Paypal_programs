package com.paypal.foodDelivery.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.paypal.foodDelivery.model.Customer;

public interface CustomerRepository extends JpaRepository<Customer, Long>
{

}
