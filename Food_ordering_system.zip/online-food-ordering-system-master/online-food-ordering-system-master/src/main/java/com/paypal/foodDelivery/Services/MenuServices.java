package com.paypal.foodDelivery.Services;

import java.util.List;
import com.paypal.foodDelivery.model.Menu;
import com.paypal.foodDelivery.model.MenuItem;

public interface MenuServices {
	
	 public void addItems(Long id, List<MenuItem> items);
	 public List<Menu> getMenus();
	 public Menu findMenuById(Long id);
	 public void deleteAll();
	 public void deleteById(Long id);
	 public List<MenuItem> getItems(Long id);
	 public void upload(List<Menu> menuList);

}
