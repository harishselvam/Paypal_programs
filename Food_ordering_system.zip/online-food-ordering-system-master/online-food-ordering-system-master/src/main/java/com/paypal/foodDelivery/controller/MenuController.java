package com.paypal.foodDelivery.controller;


import com.paypal.foodDelivery.Services.MenuServices;
import com.paypal.foodDelivery.model.Menu;
import com.paypal.foodDelivery.model.MenuItem;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Slf4j
@RestController
@RequestMapping("/menus")
public class MenuController {

	@Autowired
	private MenuServices menuServices;

    @GetMapping("/")
    public List<Menu> getMenus() {
        return menuServices.getMenus();
    }

    @GetMapping("/{id}")
    public Menu findMenuById(@PathVariable("id") Long id) {
        return menuServices.findMenuById(id);
    }

    @PostMapping("/")
    @ResponseStatus(HttpStatus.CREATED)
    public void upload(@RequestBody List<Menu> menuList) {
        menuServices.upload(menuList);
    }

    @DeleteMapping("/")
    public void deleteAll() {
        menuServices.deleteAll();
    }

    @DeleteMapping("/{id}")
    public void deleteById(@PathVariable("id") Long id) {
    	menuServices.deleteById(id);
    }

    @RequestMapping("/{id}/items/")
    public List<MenuItem> getItems(@PathVariable("id") Long id) {
        return menuServices.getItems(id);
    }

    @PostMapping("/{id}/items/")
    public void addItems(@PathVariable("id") Long id,@RequestBody List<MenuItem> items) {
        menuServices.addItems(id, items);
    }
}
