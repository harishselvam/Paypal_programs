package com.paypal.foodDelivery.Services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.paypal.foodDelivery.Repository.MenuItemRepository;
import com.paypal.foodDelivery.model.MenuItem;

@Service
public class MenuItemsServiceImpl implements MenuItemsService {

	 @Autowired
	 private MenuItemRepository menuItemRepository;
	 
	@Override
	public List<MenuItem> getMenItems() {
		// TODO Auto-generated method stub
		return menuItemRepository.findAll();
	}

	@Override
	public MenuItem findMenuById(Long id) {
		// TODO Auto-generated method stub
		return menuItemRepository.findOne(id);
	}

	@Override
	public void upload(List<MenuItem> menuItemList) {
		// TODO Auto-generated method stub
		 menuItemRepository.save(menuItemList);
		
	}

	@Override
	public void deleteAll() {
		menuItemRepository.deleteAll();
	}

	@Override
	public void deleteById(Long id) {
		menuItemRepository.delete(id);
		
	}

}
