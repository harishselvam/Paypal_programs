package com.paypal.foodDelivery;

import com.paypal.foodDelivery.Repository.CustomerRepository;
import com.paypal.foodDelivery.Repository.OrderRepository;
import com.paypal.foodDelivery.Repository.RestaurantRepository;
import com.paypal.foodDelivery.model.Customer;
import com.paypal.foodDelivery.model.Menu;
import com.paypal.foodDelivery.model.MenuItem;
import com.paypal.foodDelivery.model.Order;
import com.paypal.foodDelivery.model.Restaurant;

import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;

@SpringBootApplication
public class OnlineFoodOrderingApp {

    public static void main(String[] args) {
        SpringApplication.run(OnlineFoodOrderingApp.class, args);
    }

    @Bean
    public ApplicationRunner demo(RestaurantRepository cr, OrderRepository or, CustomerRepository cur) {
        return args -> {
        	Restaurant r1 = new Restaurant(null,"Restaurant1", "Location1", null);
          Menu menu = new Menu(null, "name1", "info1", r1);
          MenuItem m = new MenuItem(null,"Dosa","NOINFO","NOURL",20.00);
          MenuItem m1 = new MenuItem(null,"Idli","NOINFO","NOURL",15.00);
          m.setMenu(menu);
          m1.setMenu(menu);
          MenuItem[] mlist = {m,m1};
          menu.setItems(new LinkedList<>(Arrays.asList(mlist)));
          Menu[] menus = {menu};
          r1.setMenus(new LinkedList<>(Arrays.asList(menus)));
          cr.save(r1);
         cr.save(new Restaurant(null, "Restaurant2", "Location2", null));
         
         Order order = new Order(null,r1,null,new LinkedList<>(Arrays.asList(mlist)),0.00);
         List<Order> order_list = new LinkedList<>();
         order_list.add(order);
         Customer customer = new Customer(null,"harish",98920L,"chennai",order_list);
         order.setCustomer(customer);
         r1.setOrder_list(order_list);
         for (MenuItem i : mlist)
         {
        	 i.setOrder_list(order_list);
         }
         cur.save(customer);
         or.save(order);
        };
    }
}
