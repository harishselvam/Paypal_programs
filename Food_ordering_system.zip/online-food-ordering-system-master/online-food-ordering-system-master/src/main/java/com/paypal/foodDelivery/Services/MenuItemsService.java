package com.paypal.foodDelivery.Services;

import java.util.List;
import com.paypal.foodDelivery.model.MenuItem;

public interface MenuItemsService {

	public List<MenuItem> getMenItems();
	public MenuItem findMenuById(Long id);
	public void upload( List<MenuItem> menuItemList);
	public void deleteAll();
	public void deleteById(Long id);
}
