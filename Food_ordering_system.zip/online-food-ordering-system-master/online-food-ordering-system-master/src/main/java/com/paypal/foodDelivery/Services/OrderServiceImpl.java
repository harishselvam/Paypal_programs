package com.paypal.foodDelivery.Services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.paypal.foodDelivery.Repository.OrderRepository;
import com.paypal.foodDelivery.model.MenuItem;
import com.paypal.foodDelivery.model.Order;

@Service
public class OrderServiceImpl implements OrderService {

	@Autowired
    private OrderRepository orderRepository ;
 
	@Override
	public void upload(List<Order> orders) {
		orderRepository.save(orders);
		
	}

	@Override
	public List<Order> getOrder() {
		List<Order> Orders = orderRepository.findAll();
        return Orders;
	}

	@Override
	public Order findOrderById(Long id) {
		return orderRepository.findOne(id);
	}

	@Override
	public String findOrderinfoById(Long id) {
		double price = 0d;
		 List<MenuItem> price_list = orderRepository.findOne(id).getItems();
		 for(MenuItem items : price_list)
		 {
			 price+=items.getPrice();
		 }
	       String output = "Restaurant Name : " +orderRepository.findOne(id).getRestaurant().getName().toString() +
	    		   		"Customer Name :" + orderRepository.findOne(id).getCustomer().getName().toString() +
	    		   		"Order List :" + orderRepository.findOne(id).getItems().toString() +
	    		   		"Price : " + price;
		return output;
	}

}
