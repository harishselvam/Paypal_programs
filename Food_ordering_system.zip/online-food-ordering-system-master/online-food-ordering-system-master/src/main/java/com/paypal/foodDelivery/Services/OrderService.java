package com.paypal.foodDelivery.Services;

import java.util.List;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;

import com.paypal.foodDelivery.model.Order;

public interface OrderService {
	
	public void upload(@RequestBody List<Order> orders);
	public List<Order> getOrder();
	public Order findOrderById(@PathVariable("id") Long id);
	public String findOrderinfoById(@PathVariable("id") Long id);
}
