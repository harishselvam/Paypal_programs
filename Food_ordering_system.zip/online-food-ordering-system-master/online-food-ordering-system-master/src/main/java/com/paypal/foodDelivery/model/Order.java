package com.paypal.foodDelivery.model;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.*;

import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "order_table")
@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@NoArgsConstructor

public class Order 
{
	 	@Id
	    @GeneratedValue
	    private Long id;

		
		  @ManyToOne
		  @JoinColumn(name = "restaurant_id") private Restaurant restaurant;
		
		  @ManyToOne
		  @JoinColumn(name = "customer_id") private Customer customer;
		  
		  @ManyToMany
		  @JoinTable( name = "order_items", joinColumns = @JoinColumn(name =
		  "order_id"), inverseJoinColumns = @JoinColumn(name = "menuitem_id")) private
		  List<MenuItem> items;
		 
		  private double amount;

		public Order() {
			super();
		}

		public Order(Long id, Restaurant restaurant, Customer customer, List<MenuItem> items, double amount) {
			super();
			this.id = id;
			this.restaurant = restaurant;
			this.customer = customer;
			this.items = items;
			
			this.amount = amount;
		}

		public Long getId() {
			return id;
		}

		public void setId(Long id) {
			this.id = id;
		}

			  public Restaurant getRestaurant() { return restaurant; }
		  
		  public void setRestaurant(Restaurant restaurant) { this.restaurant =
		 restaurant; }
		 

		
			  public Customer getCustomer() { return customer; }
			  
			  public void setCustomer(Customer customer) { this.customer = customer; }
			  
			  public List<MenuItem> getItems() { return items; }
			  
			 public void setItems(List<MenuItem> items) { this.items = items; }
			 

		public double getAmount() {
			return amount;
		}

		public void setAmount(double amount) {
			this.amount = amount;
		}
	    
	    
	    
}
