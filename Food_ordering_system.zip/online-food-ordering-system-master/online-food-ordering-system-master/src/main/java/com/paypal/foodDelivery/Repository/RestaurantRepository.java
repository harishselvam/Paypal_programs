package com.paypal.foodDelivery.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.paypal.foodDelivery.model.Restaurant;

public interface RestaurantRepository extends JpaRepository<Restaurant, Long> {
}
