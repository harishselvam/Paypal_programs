package com.paypal.foodDelivery.model;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;

import com.fasterxml.jackson.annotation.*;

import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
@NoArgsConstructor

public class Customer
{
	 @Id
	    @GeneratedValue
	    private Long id;

	 	private String Name;

	    private Long phone;
	    
	    private String address;
	    
	    @OneToMany(mappedBy = "customer", cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.EAGER)
	    private List<Order> order_list;
	    
	    public Customer() {super();}

		public Customer(Long id, String name, Long phone, String address, List<Order> order_list) {
			super();
			this.id = id;
			Name = name;
			this.phone = phone;
			this.address = address;
			this.order_list = order_list;
		}



		public Long getId() {
			return id;
		}

		public void setId(Long id) {
			this.id = id;
		}

		public String getName() {
			return Name;
		}

		public void setName(String name) {
			Name = name;
		}

		public Long getPhone() {
			return phone;
		}

		public void setPhone(Long phone) {
			this.phone = phone;
		}

		public String getAddress() {
			return address;
		}

		public void setAddress(String address) {
			this.address = address;
		}

		public List<Order> getOrder_list() {
			return order_list;
		}

		public void setOrder_list(List<Order> order_list) {
			this.order_list = order_list;
		}
	    
	    

	   
	    
}
