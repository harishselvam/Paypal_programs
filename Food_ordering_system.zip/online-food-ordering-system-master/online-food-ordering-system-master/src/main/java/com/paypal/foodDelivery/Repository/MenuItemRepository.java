package com.paypal.foodDelivery.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.paypal.foodDelivery.model.MenuItem;


public interface MenuItemRepository extends JpaRepository<MenuItem, Long> {

}
